﻿using System.ComponentModel.DataAnnotations;

namespace ECommerceMVCApp.Models
{
    public class Product
    {
        public int ID { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        [DataType(DataType.Currency)]
        public decimal Price { get; set; }

        [Required]
        public int Quantity { get; set; }

        public string ImgURL { get; set; }

        // Foreign key
        public int CategoryID { get; set; }

        // Navigation property
        public Category Category { get; set; }
    }
}