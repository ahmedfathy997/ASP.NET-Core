﻿using System.ComponentModel.DataAnnotations;

namespace ECommerceMVCApp.Models
{
    public class Category
    {
        public int ID { get; set; }

        [Required]
        public string Name { get; set; }

        public List<Product> Products { get; set; }
    }
}