﻿using ECommerceMVCApp.Models;
using ECommerceMVCApp.Repositories.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ECommerceMVCApp.Controllers
{
    [Route("Product")]
    public class ProductController : Controller
    {
        private readonly IProductService _productService;

        public ProductController(IProductService productService)
        {
            _productService = productService;
        }

        [HttpGet]
        [Route("")]
        public async Task<IActionResult> Index()
        {
            var products = await _productService.GetAllProductsAsync();
            return View(products);
        }

        [HttpGet]
        [Route("Details/{id}")]
        public async Task<IActionResult> Details(int id)
        {
            var product = await _productService.GetProductByIdAsync(id);
            return View(product);
        }

        [HttpGet]
        [Route("Create")]
        public async Task<IActionResult> Create()
        {

            return View();
        }
        [Authorize]
        [HttpPost]
        [Route("Create")]
        public async Task<IActionResult> Create(Product product)
        {
            await _productService.AddProductAsync(product);
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        [Route("Edit/{id}")]
        public async Task<IActionResult> Edit(int id)
        {
            var product = await _productService.GetProductByIdAsync(id);
            if (product == null)
            {
                return NotFound(); // Product with the given id was not found
            }

            return View(product);
        }

        [Authorize]
        [HttpPost]
        [Route("Edit/{id}")]
        public async Task<IActionResult> EditItem(int id, Product updatedProduct)
        {
            if (ModelState.IsValid)
            {
                updatedProduct.ID = id; // Ensure the ID is set correctly

                try
                {
                    await _productService.UpdateProductAsync(updatedProduct);
                    return RedirectToAction(nameof(Index));
                }
                catch (InvalidOperationException)
                {
                    return NotFound(); // Product with the given id was not found
                }
            }
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        [Route("Delete/{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var product = await _productService.GetProductByIdAsync(id);
            if (product == null)
            {
                return NotFound(); // Product with the given id was not found
            }

            return View(product);
        }

        [Authorize]
        [HttpPost]
        [Route("Delete/{id}")]
        public async Task<IActionResult> DeleteItem(int id)
        {
            await _productService.DeleteProductAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }

}
