﻿using ECommerceMVCApp.Models;

namespace ECommerceMVCApp.Repositories.Interfaces
{
    public interface IProductService
    {
        Task<List<Product>> GetAllProductsAsync();
        Task<List<Product>> GetProductsByCategoryAsync(int categoryId);
        Task<Product> GetProductByIdAsync(int productId);
        Task AddProductAsync(Product product);
        Task UpdateProductAsync(Product updatedProduct);
        Task DeleteProductAsync(int id);
    }
}
