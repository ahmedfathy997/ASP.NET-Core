﻿using ECommerceMVCApp.Context;
using ECommerceMVCApp.Models;
using ECommerceMVCApp.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace ECommerceMVCApp.Repositories.Models
{
    public class ProductService : IProductService
    {
        private readonly AppDbContext _context;

        public ProductService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Product>> GetAllProductsAsync()
        {
            return await _context.Products.ToListAsync();
        }

        public async Task<List<Product>> GetProductsByCategoryAsync(int categoryId)
        {
            return await _context.Products.Include(c => c.Category).Where(p => p.CategoryID == categoryId).ToListAsync();
        }

        public async Task<Product> GetProductByIdAsync(int productId)
        {
            return await _context.Products.FirstOrDefaultAsync(p => p.ID == productId);
        }

        public async Task AddProductAsync(Product product)
        {
            _context.Products.Add(product);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateProductAsync(Product updatedProduct)
        {
            var product = await _context.Products.FirstOrDefaultAsync(p => p.ID == updatedProduct.ID);

            if (product == null)
            {
                throw new InvalidOperationException("Product not found in database.");
            }

            // Update product properties
            product.Name = updatedProduct.Name;
            product.Price = updatedProduct.Price;
            product.Quantity = updatedProduct.Quantity;
            product.ImgURL = updatedProduct.ImgURL;
            product.Category = updatedProduct.Category;
            product.CategoryID = updatedProduct.CategoryID;

            await _context.SaveChangesAsync();
        }
        public async Task DeleteProductAsync(int id)
        {
            var product = await _context.Products.FirstOrDefaultAsync(p => p.ID == id);
            _context.Products.Remove(product);
            await _context.SaveChangesAsync();
        }
    }

}
