﻿namespace PieShop.Models
{
    public interface IPieRepository
    {
        IEnumerable<Pie> AllPies { get; }
        IEnumerable<Pie> PiesOfTheWeek { get; }

        Pie? GetPiebyId(int pieid);

        IEnumerable<Pie> SearchPies(string searchQuery);
    }
}
