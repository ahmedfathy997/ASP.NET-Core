using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using PieShop.Models;
using System.Text.Json.Serialization;

namespace BethaneysPieShop
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            var connectionString = builder.Configuration.GetConnectionString("PieShopDbContextConnection") ?? throw new InvalidOperationException("Connection string 'PieShopDbContextConnection' not found.");

            // My Services
            builder.Services.AddScoped<ICategoryRepository, CategoryRepository>();
            builder.Services.AddScoped<IPieRepository, PieRepository>();
            builder.Services.AddScoped<IOrderRepository, OrderRepository>();

            builder.Services.AddScoped<IShoppingCart, ShoppingCart>(
                sp => ShoppingCart.GetCart(sp));
            builder.Services.AddSession();
            builder.Services.AddHttpContextAccessor();

            builder.Services.AddRazorPages();

            // App Services
            builder.Services.AddControllersWithViews();

            builder.Services.AddDbContext<PieShopDbContext>(options =>
            {
                options.UseSqlServer(
                    builder.Configuration["ConnectionStrings:PieShopDbContextConnection"]);
            });

            builder.Services.AddDefaultIdentity<IdentityUser>(options => options.SignIn.RequireConfirmedAccount = true).AddEntityFrameworkStores<PieShopDbContext>();

            builder.Services.AddControllers()
                .AddJsonOptions(options =>
                {
                    options.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
                });
            builder.Services.AddServerSideBlazor();

            var app = builder.Build(); // Create App

            app.UseStaticFiles();
            app.UseSession();
            app.UseAuthentication();
            app.UseAuthorization();

            if (app.Environment.IsDevelopment()) // check for dev env
            {
                app.UseDeveloperExceptionPage(); // use exception page
            }

            app.MapDefaultControllerRoute();
            app.MapRazorPages();

            app.MapBlazorHub();
            app.MapFallbackToPage("/app/{*catchall}", "/App/Index");

            app.MapControllers();
            DbInitializer.Seed(app);
            // Run
            app.Run();
        }
    }
}
