﻿using AutoMapper;
namespace City.API.Profiles
{
    public class CityProfile : Profile
    {
        public CityProfile()
        {
            CreateMap<Entities.Cities, Models.CityWithoutPoints>();
            CreateMap<Entities.Cities, Models.CityDto>();
        }
    }
}
