﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace City.API.Entities
{
    public class Cities
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required]
        [MaxLength(20)]
        public string Name { get; set; }
        [MaxLength(200)]
        public string? Description { get; set; }
        public int NumberOfPointsOfInterset
        {
            get
            {
                return PointsOfInterset.Count;
            }
        }
        public ICollection<PointOfInterest> PointsOfInterset { get; set; }
            = new List<PointOfInterest>();

        public Cities(string name)
        {
            Name = name;
        }
    }
}
