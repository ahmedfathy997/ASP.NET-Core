﻿using System.ComponentModel.DataAnnotations;

namespace City.API.Models
{
    public class PointsOfInterestForUpdateDto
    {
        [Required(ErrorMessage = "Field name is required.")]
        [MaxLength(50)]
        public string Name { get; set; } = string.Empty;
        [MaxLength(200)]
        public string? Description { get; set; }
    }
}
