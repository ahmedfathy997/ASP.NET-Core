﻿using City.API.Entities;

namespace City.API.Services
{
    public interface ICityInfoRepository
    {
        Task<IEnumerable<Cities>> GetCitiesAsync();
        Task<(IEnumerable<Cities>, PaginationMetadata)> GetCitiesAsync(string? name, string? searchQuery, int pageNumber, int pageSize);
        Task<Cities?> GetCityAsync(int cityId, bool incloudPointOfInterest);
        Task<IEnumerable<PointOfInterest>> GetPointsOfInterestForCityAsync(int cityId);
        Task<bool> CityExistsAsync(int id);
        Task<IEnumerable<PointOfInterest?>> GetPointOfInterestForCityAsync
            (int cityId,
            int pointOfInterestId
            );
        Task AddPointOfInterestForCityAsync(int cityId, PointOfInterest pointOfInterest);
        void DeletePointOfInterest(PointOfInterest pointOfInterest);
        Task<bool> CityNameMatchesCityId(string? cityName, int cityId);
        Task<bool> SaveChangesAsync();
    }
}
