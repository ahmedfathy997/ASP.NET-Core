﻿using Microsoft.EntityFrameworkCore;
using SimpleRESTAPI.Models;

namespace SimpleRESTAPI.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Category>().HasData(
                new Category { ID = 1, Name = "Electronics" },
                new Category { ID = 2, Name = "Clothing" }
            );

            modelBuilder.Entity<Product>().HasData(
                new Product { ID = 1, Name = "Laptop", Price = 999.99m, Quantity = 10, CategoryID = 1, ImgURL = "/Images/laptop.jpg" },
                new Product { ID = 2, Name = "Smartphone", Price = 599.99m, Quantity = 20, CategoryID = 1, ImgURL = "/Images/smartphone.jpg" },
                new Product { ID = 3, Name = "T-Shirt", Price = 19.99m, Quantity = 50, CategoryID = 2, ImgURL = "/Images/tshirt.jpg" },
                new Product { ID = 4, Name = "Jeans", Price = 39.99m, Quantity = 30, CategoryID = 2, ImgURL = "/Images/jeans.jpg" }
            );

            base.OnModelCreating(modelBuilder);
        }
    }
}
