﻿using System.ComponentModel.DataAnnotations;

namespace SimpleRESTAPI.Models
{
    public class Category
    {
        public int ID { get; set; }

        [Required(ErrorMessage = "Name is required")]
        public string Name { get; set; }
    }
}
