﻿using SimpleRESTAPI.Data;
using SimpleRESTAPI.Models;

namespace SimpleRESTAPI.Services
{
    public class CategoryService : ICategoryService
    {
        private readonly AppDbContext _context;

        public CategoryService(AppDbContext context)
        {
            _context = context;
        }

        public IEnumerable<Category> GetCategories()
        {
            return _context.Categories.ToList();
        }

        public Category GetCategoryById(int id)
        {
            return _context.Categories.FirstOrDefault(c => c.ID == id);
        }

        public Category CreateCategory(Category category)
        {
            _context.Categories.Add(category);
            _context.SaveChanges();
            return category;
        }

        public Category UpdateCategory(int id, Category category)
        {
            var existingCategory = _context.Categories.Find(id);
            if (existingCategory == null)
            {
                throw new Exception("Category not found");
            }
            existingCategory.Name = category.Name;
            _context.SaveChanges();
            return existingCategory;
        }

        public void DeleteCategory(int id)
        {
            var category = _context.Categories.Find(id);
            if (category == null)
            {
                throw new Exception("Category not found");
            }
            _context.Categories.Remove(category);
            _context.SaveChanges();
        }
    }
}
